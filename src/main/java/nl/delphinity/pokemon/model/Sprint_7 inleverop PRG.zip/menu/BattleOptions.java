package nl.delphinity.pokemon.model.menu;

public enum BattleOptions {
    FIGHT, POKEMON, ITEM, RUN
}
